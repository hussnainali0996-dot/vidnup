﻿import asyncio
import os
import uuid
import json
import threading
import tempfile
import shutil
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel

from downloader import VideoDownloader

# ── App setup ────────────────────────────────────────────────────────────────

app = FastAPI(title="Video Downloader API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory task store ──────────────────────────────────────────────────────
tasks: Dict[str, Dict[str, Any]] = {}
TEMP_ROOT = tempfile.mkdtemp(prefix="vdl_")
downloader = VideoDownloader()

# ── Models ────────────────────────────────────────────────────────────────────

class InfoRequest(BaseModel):
    urls: List[str]

class StartRequest(BaseModel):
    url: str
    format_id: str
    title: str = "video"

# ── Background download ───────────────────────────────────────────────────────

def _run_download(task_id: str, url: str, format_id: str, title: str):
    task = tasks[task_id]
    task_dir = os.path.join(TEMP_ROOT, task_id)
    os.makedirs(task_dir, exist_ok=True)

    def progress_hook(d):
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            downloaded = d.get("downloaded_bytes", 0)
            pct = int(downloaded / total * 100) if total else 0
            task["status"] = "downloading"
            task["progress"] = pct
            task["speed"] = d.get("_speed_str", "").strip()
            task["eta"] = d.get("eta") or 0
        elif d["status"] == "finished":
            task["progress"] = 99
            task["speed"] = ""
            task["eta"] = 0

    try:
        filepath = downloader.download(
            url=url,
            format_id=format_id,
            output_dir=task_dir,
            progress_hook=progress_hook,
        )
        task["filepath"] = filepath
        task["filename"] = os.path.basename(filepath)
        task["status"] = "done"
        task["progress"] = 100
    except Exception as exc:
        task["status"] = "error"
        task["error"] = str(exc)

# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return {"status": "ok", "message": "Video Downloader API is running"}

@app.post("/api/info")
async def get_info(req: InfoRequest):
    if not req.urls:
        raise HTTPException(status_code=400, detail="No URLs provided")
    results = []
    for url in req.urls:
        url = url.strip()
        if not url:
            continue
        try:
            info = downloader.get_info(url)
            info["url"] = url
            results.append({"ok": True, "data": info})
        except Exception as exc:
            results.append({"ok": False, "url": url, "error": str(exc)})
    return {"results": results}

@app.post("/api/start")
async def start_download(req: StartRequest, background_tasks: BackgroundTasks):
    task_id = str(uuid.uuid4())
    tasks[task_id] = {
        "status": "pending",
        "progress": 0,
        "speed": "",
        "eta": 0,
        "filepath": None,
        "filename": None,
        "error": None,
    }
    t = threading.Thread(
        target=_run_download,
        args=(task_id, req.url, req.format_id, req.title),
        daemon=True,
    )
    t.start()
    return {"task_id": task_id}

@app.get("/api/progress/{task_id}")
async def progress_stream(task_id: str):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")

    async def event_generator():
        while True:
            task = tasks.get(task_id, {})
            payload = json.dumps({
                "status": task.get("status"),
                "progress": task.get("progress", 0),
                "speed": task.get("speed", ""),
                "eta": task.get("eta", 0),
                "error": task.get("error"),
            })
            yield f"data: {payload}\n\n"
            if task.get("status") in ("done", "error"):
                break
            await asyncio.sleep(0.5)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )

@app.get("/api/file/{task_id}")
async def serve_file(task_id: str, background_tasks: BackgroundTasks):
    task = tasks.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    if task["status"] != "done":
        raise HTTPException(status_code=409, detail="Download not complete yet")
    filepath = task["filepath"]
    filename = task["filename"]
    if not filepath or not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File not found on server")

    def cleanup():
        task_dir = os.path.dirname(filepath)
        shutil.rmtree(task_dir, ignore_errors=True)
        tasks.pop(task_id, None)

    background_tasks.add_task(cleanup)
    return FileResponse(path=filepath, filename=filename, media_type="application/octet-stream")
