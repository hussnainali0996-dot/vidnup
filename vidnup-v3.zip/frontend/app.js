/* ── Config ─────────────────────────────────────────────────────────────── */
// Empty string = same server (works automatically on Railway).
// Change to a full URL only if running frontend and backend separately.
const DEFAULT_BACKEND = "";

/* ── State ───────────────────────────────────────────────────────────────── */
let backendUrl = localStorage.getItem("backendUrl") || DEFAULT_BACKEND;

/* ── DOM refs ────────────────────────────────────────────────────────────── */
const urlInput       = document.getElementById("url-input");
const fetchBtn       = document.getElementById("fetch-btn");
const clearBtn       = document.getElementById("clear-btn");
const downloadAllBtn = document.getElementById("download-all-btn");
const fetchError     = document.getElementById("fetch-error");
const queue          = document.getElementById("queue");
const backendInput   = document.getElementById("backend-url");
const statusDot      = document.getElementById("status-dot");

/* ── Init ────────────────────────────────────────────────────────────────── */
backendInput.value = backendUrl;
checkBackendHealth();

backendInput.addEventListener("change", () => {
  backendUrl = backendInput.value.trim().replace(/\/$/, "");
  localStorage.setItem("backendUrl", backendUrl);
  checkBackendHealth();
});

/* ── Health check ────────────────────────────────────────────────────────── */
async function checkBackendHealth() {
  try {
    const r = await fetch(`${backendUrl}/`, { signal: AbortSignal.timeout(4000) });
    statusDot.className = r.ok ? "dot" : "dot offline";
  } catch {
    statusDot.className = "dot offline";
  }
}

/* ── Fetch info ──────────────────────────────────────────────────────────── */
fetchBtn.addEventListener("click", fetchInfo);

async function fetchInfo() {
  const raw = urlInput.value.trim();
  if (!raw) return;

  const urls = raw.split("\n").map(u => u.trim()).filter(Boolean);
  if (!urls.length) return;

  fetchBtn.disabled = true;
  fetchBtn.textContent = "Fetching…";
  fetchError.style.display = "none";

  try {
    const res = await fetch(`${backendUrl}/api/info`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ urls }),
    });
    if (!res.ok) throw new Error(`Server error ${res.status}`);
    const data = await res.json();

    for (const result of data.results) {
      if (result.ok) {
        appendVideoCard(result.data);
      } else {
        appendErrorCard(result.url, result.error);
      }
    }
    urlInput.value = "";
    updateDownloadAllBtn();
  } catch (err) {
    fetchError.textContent = `❌ ${err.message}`;
    fetchError.style.display = "block";
  } finally {
    fetchBtn.disabled = false;
    fetchBtn.textContent = "Fetch Info";
  }
}

/* ── Clear queue ─────────────────────────────────────────────────────────── */
clearBtn.addEventListener("click", () => {
  queue.innerHTML = "";
  updateDownloadAllBtn();
});

/* ── Download All ────────────────────────────────────────────────────────── */
downloadAllBtn.addEventListener("click", () => {
  const downloadBtns = queue.querySelectorAll(".download-btn:not(:disabled)");
  downloadBtns.forEach(btn => btn.click());
});

function updateDownloadAllBtn() {
  const count = queue.querySelectorAll(".video-card").length;
  downloadAllBtn.style.display = count > 1 ? "inline-block" : "none";
}

/* ── Platform detection ──────────────────────────────────────────────────── */
function detectPlatform(platform) {
  if (!platform) return "unknown";
  if (platform.includes("youtube")) return "youtube";
  if (platform.includes("tiktok"))  return "tiktok";
  if (platform.includes("instagram") || platform.includes("insta")) return "instagram";
  return platform;
}

function platformLabel(p) {
  return { youtube: "YouTube", tiktok: "TikTok", instagram: "Instagram" }[p] || p;
}

function platformEmoji(p) {
  return { youtube: "▶️", tiktok: "🎵", instagram: "📸" }[p] || "🎬";
}

function formatFilesize(bytes) {
  if (!bytes) return "";
  if (bytes > 1e9) return `~${(bytes / 1e9).toFixed(1)} GB`;
  if (bytes > 1e6) return `~${(bytes / 1e6).toFixed(0)} MB`;
  return `~${(bytes / 1e3).toFixed(0)} KB`;
}

function formatDuration(secs) {
  if (!secs) return "";
  const m = Math.floor(secs / 60);
  const s = String(secs % 60).padStart(2, "0");
  return `${m}:${s}`;
}

/* ── Append video card ───────────────────────────────────────────────────── */
function appendVideoCard(data) {
  const platform = detectPlatform(data.platform);
  const card = document.createElement("div");
  card.className = `video-card platform-${platform}`;
  card.dataset.url = data.url;

  // Format options HTML
  const optionsHtml = (data.formats || []).map(f => {
    const size = formatFilesize(f.filesize);
    return `<option value="${f.format_id}">${f.label}${size ? " · " + size : ""}</option>`;
  }).join("");

  const thumbHtml = data.thumbnail
    ? `<img class="vc-thumb" src="${data.thumbnail}" alt="thumbnail" onerror="this.style.display='none'">`
    : `<div class="vc-thumb-placeholder">${platformEmoji(platform)}</div>`;

  const duration = formatDuration(data.duration);

  card.innerHTML = `
    <div class="vc-header">
      ${thumbHtml}
      <div class="vc-meta">
        <div class="vc-title">${escHtml(data.title)}</div>
        <div class="vc-uploader">${escHtml(data.uploader || "")}${duration ? " · " + duration : ""}</div>
        <div class="vc-platform-badge">${platformEmoji(platform)} ${platformLabel(platform)}</div>
      </div>
    </div>
    <div class="vc-controls">
      <select class="format-select">${optionsHtml || "<option>No formats found</option>"}</select>
      <button class="btn-primary download-btn">Download</button>
    </div>
    <div class="vc-progress">
      <div class="status-text">Preparing…</div>
      <div class="progress-bar-track">
        <div class="progress-bar-fill"></div>
      </div>
      <div class="progress-meta">
        <span class="speed-text"></span>
        <span class="pct-text">0%</span>
      </div>
    </div>
  `;

  queue.appendChild(card);

  card.querySelector(".download-btn").addEventListener("click", () => {
    startDownload(card, data);
  });
}

function appendErrorCard(url, error) {
  const card = document.createElement("div");
  card.className = "video-card";
  card.innerHTML = `
    <div class="vc-header">
      <div class="vc-thumb-placeholder">⚠️</div>
      <div class="vc-meta">
        <div class="vc-title" style="color:#ef4444">Failed to fetch info</div>
        <div class="vc-uploader">${escHtml(url)}</div>
        <div class="vc-uploader" style="color:#ef4444;margin-top:4px">${escHtml(error)}</div>
      </div>
    </div>
  `;
  queue.appendChild(card);
}

/* ── Start download ──────────────────────────────────────────────────────── */
async function startDownload(card, data) {
  const formatId = card.querySelector(".format-select").value;
  const downloadBtn = card.querySelector(".download-btn");
  const progressSection = card.querySelector(".vc-progress");
  const statusText = card.querySelector(".status-text");
  const fillBar = card.querySelector(".progress-bar-fill");
  const pctText = card.querySelector(".pct-text");
  const speedText = card.querySelector(".speed-text");

  downloadBtn.disabled = true;
  progressSection.style.display = "block";
  statusText.className = "status-text";
  statusText.textContent = "Starting…";

  let taskId;

  try {
    // Start the download task
    const res = await fetch(`${backendUrl}/api/start`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: data.url, format_id: formatId, title: data.title }),
    });
    if (!res.ok) throw new Error(`Server error ${res.status}`);
    const json = await res.json();
    taskId = json.task_id;
  } catch (err) {
    statusText.className = "status-text error";
    statusText.textContent = `❌ ${err.message}`;
    downloadBtn.disabled = false;
    return;
  }

  // SSE progress stream
  const evtSource = new EventSource(`${backendUrl}/api/progress/${taskId}`);

  evtSource.onmessage = async (event) => {
    const d = JSON.parse(event.data);

    fillBar.style.width = d.progress + "%";
    pctText.textContent = d.progress + "%";

    if (d.status === "downloading") {
      statusText.textContent = "Downloading…";
      speedText.textContent = d.speed || "";
    } else if (d.status === "pending") {
      statusText.textContent = "Waiting in queue…";
    }

    if (d.status === "done") {
      evtSource.close();
      statusText.className = "status-text done";
      statusText.textContent = "✅ Done! Saving file…";
      speedText.textContent = "";
      // Trigger browser file download
      triggerFileDownload(taskId, data.title);
    } else if (d.status === "error") {
      evtSource.close();
      statusText.className = "status-text error";
      statusText.textContent = `❌ ${d.error || "Unknown error"}`;
      downloadBtn.disabled = false;
    }
  };

  evtSource.onerror = () => {
    evtSource.close();
    statusText.className = "status-text error";
    statusText.textContent = "❌ Connection lost";
    downloadBtn.disabled = false;
  };
}

/* ── File download trigger ───────────────────────────────────────────────── */
function triggerFileDownload(taskId, title) {
  const a = document.createElement("a");
  a.href = `${backendUrl}/api/file/${taskId}`;
  a.download = title || "video";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

/* ── Utility ─────────────────────────────────────────────────────────────── */
function escHtml(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

/* ── Enter key shortcut ──────────────────────────────────────────────────── */
urlInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) fetchInfo();
});
