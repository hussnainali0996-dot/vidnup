import os
import shutil
import yt_dlp

# ── ffmpeg detection ──────────────────────────────────────────────────────────
# Try PATH first, then fall back to known winget install location.
_WINGET_FFMPEG = (
    r"C:\Users\kalak\AppData\Local\Microsoft\WinGet\Packages"
    r"\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe"
    r"\ffmpeg-9.0.1-full_build\bin\ffmpeg.exe"
)

def _find_ffmpeg() -> str | None:
    """Return ffmpeg executable path, or None if not found."""
    via_path = shutil.which("ffmpeg")
    if via_path:
        return via_path
    if os.path.isfile(_WINGET_FFMPEG):
        return _WINGET_FFMPEG
    return None

FFMPEG_PATH = _find_ffmpeg()
FFMPEG_AVAILABLE = FFMPEG_PATH is not None


class VideoDownloader:
    """Thin wrapper around yt-dlp for info extraction and downloading."""

    # ── Public API ──────────────────────────────────────────────────────────

    def get_info(self, url: str) -> dict:
        """Return video metadata + available format list for a URL."""
        opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            **self._platform_opts(url),
        }
        with yt_dlp.YoutubeDL(opts) as ydl:
            raw = ydl.extract_info(url, download=False)
            return self._parse_info(raw)

    def _platform_opts(self, url: str) -> dict:
        """Extra yt-dlp options tailored per platform."""
        url_lower = url.lower()

        # TikTok: yt-dlp handles TikTok natively — no special options needed.
        # Extra options (api_hostname, cookiesfrombrowser) were causing failures.
        if "tiktok.com" in url_lower:
            return {}


        # Instagram: add Referer
        if "instagram.com" in url_lower:
            return {
                "http_headers": {
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/125.0.0.0 Safari/537.36"
                    ),
                    "Referer": "https://www.instagram.com/",
                },
            }

        return {}

    def download(
        self,
        url: str,
        format_id: str,
        output_dir: str,
        progress_hook=None,
    ) -> str:
        """
        Download a video and return the absolute path to the saved file.
        format_id is a yt-dlp format selector string, e.g. "137+140" or "best".
        """
        opts = {
            "format": format_id,
            "outtmpl": os.path.join(output_dir, "%(title)s.%(ext)s"),
            "quiet": True,
            "no_warnings": True,
            "merge_output_format": "mp4",
            "restrictfilenames": True,
            **self._platform_opts(url),
        }

        # Tell yt-dlp exactly where ffmpeg is
        if FFMPEG_AVAILABLE:
            opts["ffmpeg_location"] = os.path.dirname(FFMPEG_PATH)

        if progress_hook:
            opts["progress_hooks"] = [progress_hook]

        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=True)
            filepath = ydl.prepare_filename(info)
            base = os.path.splitext(filepath)[0]
            for ext in ("mp4", "mkv", "webm", "mp3", "m4a", "ogg"):
                candidate = f"{base}.{ext}"
                if os.path.exists(candidate):
                    return candidate
            # Fallback: any file in the output dir
            files = os.listdir(output_dir)
            if files:
                return os.path.join(output_dir, files[0])
            return filepath

    # ── Helpers ─────────────────────────────────────────────────────────────

    def _parse_info(self, info: dict) -> dict:
        formats = self._build_format_list(info)
        platform = info.get("extractor_key", "").lower()
        return {
            "title": info.get("title", "Unknown"),
            "thumbnail": info.get("thumbnail"),
            "duration": info.get("duration"),
            "uploader": info.get("uploader") or info.get("channel"),
            "platform": platform,
            "formats": formats,
        }

    def _build_format_list(self, info: dict) -> list:
        """
        Build a de-duplicated, sorted list of download options.

        YouTube serves video and audio as separate streams — these need
        ffmpeg to merge.  TikTok/Instagram serve pre-muxed streams.
        """
        raw_formats = info.get("formats", [])

        has_video_only = any(
            f.get("vcodec", "none") != "none" and f.get("acodec", "none") == "none"
            for f in raw_formats
        )

        if has_video_only and FFMPEG_AVAILABLE:
            # YouTube-style: pair each video stream with best audio
            return self._build_split_formats(raw_formats)
        else:
            # Pre-muxed (TikTok/Instagram) OR no ffmpeg available
            return self._build_muxed_formats(raw_formats)

    def _build_split_formats(self, raw_formats: list) -> list:
        """For YouTube-style split streams, pair best audio with each video."""
        audio_formats = [
            f for f in raw_formats
            if f.get("acodec", "none") != "none" and f.get("vcodec", "none") == "none"
        ]
        if not audio_formats:
            return self._build_muxed_formats(raw_formats)

        # Best audio stream
        best_audio = max(
            audio_formats,
            key=lambda f: f.get("abr") or f.get("tbr") or 0,
        )

        video_formats = [
            f for f in raw_formats
            if f.get("vcodec", "none") != "none" and f.get("height")
        ]

        # De-duplicate by height, keep highest bitrate per height
        by_height: dict = {}
        for f in video_formats:
            h = f["height"]
            existing = by_height.get(h)
            tbr = f.get("tbr") or f.get("vbr") or 0
            if existing is None or tbr > (existing.get("tbr") or existing.get("vbr") or 0):
                by_height[h] = f

        results = []
        for height in sorted(by_height.keys(), reverse=True):
            vf = by_height[height]
            size = (vf.get("filesize") or 0) + (best_audio.get("filesize") or 0)
            results.append({
                "format_id": f"{vf['format_id']}+{best_audio['format_id']}",
                "label": f"{height}p",
                "height": height,
                "ext": "mp4",
                "filesize": size or None,
            })

        # Audio-only option
        results.append({
            "format_id": best_audio["format_id"],
            "label": "Audio only (MP3)",
            "height": 0,
            "ext": "mp3",
            "filesize": best_audio.get("filesize"),
        })

        return results

    def _build_muxed_formats(self, raw_formats: list) -> list:
        """
        For pre-muxed streams (TikTok, Instagram) or YouTube fallback.
        Only includes formats that have BOTH video AND audio.
        """
        seen: set = set()
        results = []

        for f in raw_formats:
            vcodec = f.get("vcodec", "none")
            acodec = f.get("acodec", "none")
            height = f.get("height")
            ext = f.get("ext", "mp4")

            # Audio-only entries
            if vcodec == "none" and acodec != "none":
                label = f"Audio only ({ext})"
                key = "audio"
            # Must have BOTH video AND audio codecs to be included
            elif height and vcodec != "none" and acodec != "none":
                label = f"{height}p"
                key = str(height)
            else:
                continue  # skip video-only or unknown streams

            if key in seen:
                continue
            seen.add(key)

            results.append({
                "format_id": f["format_id"],
                "label": label,
                "height": height or 0,
                "ext": ext,
                "filesize": f.get("filesize") or f.get("filesize_approx"),
            })

        results.sort(key=lambda x: x.get("height") or 0, reverse=True)

        # If nothing found (e.g. all streams are split), use yt-dlp best selector
        if not results:
            results.append({
                "format_id": "best[ext=mp4]/best",
                "label": "Best available",
                "height": 0,
                "ext": "mp4",
                "filesize": None,
            })

        return results
